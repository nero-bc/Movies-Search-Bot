import random


def emoji():
    emoji = '🖥📷🎥⛩⛺️🏠🧲🧿🎁🎈🧸💮🔆🔰♻️💠'
    return random.choice(emoji)
